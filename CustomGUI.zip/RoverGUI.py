import tkinter as tk
import tkinter.messagebox
import customtkinter
import serial
from PIL import Image, ImageTk
import numpy as np
from icecream import ic
import time
import re
''' 
Created by:     Benjamin Williams   R11544055
Design For:     Project Lab III: Radio Direction Finding Base Station GUI
                Texas Tech University,
                Electrical and Computer Engineering

Map Border Dimensions: (Lab3Map.png)
Height:   858 px   -   2560 ft  -   781.3 m 
Width:   1232 px   -   3350 ft  -   1020  m
'''

ic.enable()

EX_ADD = ["40", "41", "42", "43", "44", "45"]
EX_RES = ["", "", "", "", "", ""]
buffer = 0

customtkinter.set_appearance_mode("Dark")
customtkinter.set_default_color_theme("dark-blue")

class RoverApp(customtkinter.CTk):
    WIDTH = 650
    HEIGHT = 580

    def __init__(self):
        super().__init__()
        self.title("Ben's Customized Rover Interface")
        self.geometry(f"{RoverApp.WIDTH}x{RoverApp.HEIGHT}")

        self.frame_left = customtkinter.CTkFrame(master=self, width=200, corner_radius=10, height=RoverApp.HEIGHT,
                                                 border_color="#5b5b5b", border_width=2)
        self.frame_left.grid(row=0, column=0, ipadx=20, ipady=20, padx=10, pady=10, sticky="nsew")

        self.frame_text = customtkinter.CTkFrame(master=self.frame_left, border_color="#5b5b5b", border_width=2,
                                                 corner_radius=10)
        self.frame_text.grid(row=0, column=0, padx=10, pady=10, sticky="ns")

        self.window = tk.Text(master=self.frame_text, foreground="#FFFFFF", background="#5b5b5b",
                              font=("Roboto Medium", -16), state="disabled", width=65, height=20, borderwidth=2)
        self.window.pack(padx=10, pady=10, fill="both", anchor="center")

        self.terminal = customtkinter.CTkEntry(master=self.frame_left, height=50,
                                               placeholder_text="Terminal> Enter Commands or type -help.",text_font=("Roboto Medium", -16))
        self.terminal.grid(row=1, column=0, padx=20, pady=20, sticky="ew")

        self.win_print("Commands: " 
                       "\n-help \t    : display options" 
                       "\n-send [msg] : sends a message to Base Station\n")

        self.terminal.bind("<Return>", self.parseCommand)

        self.after(1000, self.serial_poll)

    def serial_poll(self):
        if serial.isOpen():
            buffer = serial.in_waiting
            if buffer > 0:
                buffer = serial.in_waiting
                s = uartRead()
                self.win_print(s)
                print(s)
            #txt = f"AT+SEND=50,{len(choice)},{choice}"
            #uart(txt)
        self.after(500, self.serial_poll)

    def parseCommand(self, e):
        if self.terminal.get() != "":
            cmd = self.terminal.get()
            if cmd == "-help":
                txt = "Commands: " \
                      "\n-help \t    : display options" \
                      "\n[msg] : sends a message to rover\n"
                self.win_print(txt)
            elif cmd.find("-ping")!=-1:
                ping(self)
            else:
                print(f"{cmd} . {len(cmd)}")
                txt = f"AT+SEND=50,{len(cmd)},{cmd}"
                s = uart(txt)
                self.win_print(txt)
                self.win_print(s)
            self.terminal.delete(0, tk.END)
            self.terminal.insert(tk.END, "")
            return


    def win_print(self, string):
        self.window.config(state="normal")
        self.window.insert(tk.END, string)
        self.window.insert(tk.END, '\n')
        self.window.yview(tk.END)
        self.window.config(state="disabled")
        return

    def uartWrite(self, s):
        self.win_print(s)
        msg_out = f"{s}\r\n"
        Data_out = bytes(msg_out, 'utf-8')
        serial.write(Data_out)

    def uartRead(self):
        time.sleep(.5)
        data_in = serial.read_until(expected=b'\n')[:-2]
        message = data_in.decode('utf-8')
        #print(message)
        return message

    def on_closing(self, event=0):
        serial.close()
        self.destroy()

    def start(self):
        self.mainloop()

def ping(self):
    buffer = serial.in_waiting
    for i in range(6):
        reply = uart(f"AT+SEND={EX_ADD[i]},1,R")
        time.sleep(.5)
        # print(f"Sent to E{EX_ADD[i]}")
        if reply.startswith("+RCV"):
            rssi = reply.split(',')[3]
            ic(rssi)
            EX_RES[i] = rssi
            print(EX_RES[i])
    text = "$0,{0}:1,{1}:2,{2}:3,{3}:4,{4}:5,{5}".format(
        EX_RES[0], EX_RES[1], EX_RES[2], EX_RES[3], EX_RES[4], EX_RES[5])
    buffer = serial.in_waiting
    ic(text)
    s = uart(f"AT+SEND=50,{len(text)},{text}")
    self.win_print(text)
    self.win_print(s)
    if buffer > 0:
        string = uartRead()
        print(string)

def uart(s):
    print(s)
    msg_out = f"{s}\r\n"
    Data_out = bytes(msg_out, 'utf-8')
    serial.write(Data_out)

    time.sleep(.5)

    data_in = serial.read_until(expected=b'\n')[:-2]
    message = data_in.decode('utf-8')
    print(message)
    return message

def uartWrite(s):
    print(s)
    msg_out = f"{s}\r\n"
    Data_out = bytes(msg_out, 'utf-8')
    serial.write(Data_out)

def uartRead():
    time.sleep(.5)
    data_in = serial.read_until(expected=b'\n')[:-2]
    message = data_in.decode('utf-8')
    return message

if __name__ == "__main__":

    serial = serial.Serial(port='COM15', baudrate=9600)

    if not serial.isOpen():
        serial.open()

    uart("AT+BAND=915000000")
    uart("AT+ADDRESS=59")
    uart("AT+NETWORKID=4")
    uart("AT+IPR=9600")

    app = RoverApp()
    app.start()

    uart("AT+SEND=50,1,h")